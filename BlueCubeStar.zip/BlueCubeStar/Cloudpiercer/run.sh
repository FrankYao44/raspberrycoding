cd /
cd home/pi/Blue_Cube_Star
python3 AtomHeart/gui
python3 Blue_Cube_Star.py
cd /
